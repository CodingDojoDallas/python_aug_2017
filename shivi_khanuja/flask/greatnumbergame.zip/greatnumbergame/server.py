import random(redirect, render_template)
count = 0


